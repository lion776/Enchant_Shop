---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

### Issue description
-

### Steps to reproduce the issue
1. ...
2. ...

### OS and versions
<!-- try the `version` command | LATEST IS NOT A VALID VERSION -->
* PocketMine-MP:
* PHP:

### Crashdump, backtrace or other files
<!--- Submit crashdumps at https://crash.pmmp.io and paste a link -->
<!--- Use gist or anything else to add other files and add links here -->
