## EnchantShopUI [![](https://poggit.pmmp.io/shield.state/EnchantUI)](https://poggit.pmmp.io/p/EnchantUI)[![Discord](https://img.shields.io/discord/577268599165550592.svg?style=flat-square&label=discord&colorB=7289da)](https://discord.gg/6C5TVD4)

a simple enchantment shop 

## Important

- Requires EconomyAPI by ONEBONE

## Devs/Info
- Made by: UnknownOre

